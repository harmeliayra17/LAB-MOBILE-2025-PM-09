package com.example.tp1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ImageButton settings;
    ImageView fotoProfil;
    TextView nama, namaPengguna;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        settings = findViewById(R.id.btnSettings);
        fotoProfil = findViewById(R.id.profilDuo);
        nama = findViewById(R.id.nama);
        namaPengguna = findViewById(R.id.namaPengguna);

        // buton settings supaya bisa ke ma2
        settings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            // kirim data ke ma2
            String namaStr = "Parri";
            String usernameStr = "puttss";
            String imageUriStr = "android.resource://com.example.tp1/" + R.drawable.pb;

            intent.putExtra("name", namaStr);
            intent.putExtra("username", usernameStr);
            intent.putExtra("imageUri", imageUriStr);

            startActivity(intent);

            loadProfileData("parri", "puttss", "android.resource://com.example.tp1/" + R.drawable.pb);
        });

        // Load initial data (from Intent, initially set)

    }

    private void loadProfileData(String namaStr, String usernameStr, String imageUriStr) {
        nama.setText(namaStr);
        namaPengguna.setText(usernameStr);

        if (imageUriStr != null) {
            try {
                Uri imageUri = Uri.parse(imageUriStr);
                fotoProfil.setImageURI(imageUri);
            } catch (Exception e) {
                e.printStackTrace();
                fotoProfil.setImageResource(R.drawable.pb);
            }
        } else {
            fotoProfil.setImageResource(R.drawable.pb);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("done")) {
            // update data
            String name = intent.getStringExtra("name");
            String username = intent.getStringExtra("username");
            String imageUriStr = intent.getStringExtra("imageUri");

            // Update tempilannya ui nya lah
            loadProfileData(name, username, imageUriStr);
        }
    }
}
