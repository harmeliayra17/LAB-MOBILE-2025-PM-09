package com.example.tp1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    TextView doneBtn, profileBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);  // Layout for the second screen

        profileBtn = findViewById(R.id.profilebtn);
        profileBtn.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);

            // ambil data dari ma
            String name = getIntent().getStringExtra("name");
            String username = getIntent().getStringExtra("username");
            String imageUri = getIntent().getStringExtra("imageUri");

            // kirim data ke ma3
            intent.putExtra("name", name);
            intent.putExtra("username", username);
            intent.putExtra("imageUri", imageUri);

            startActivity(intent);
        });

        doneBtn = findViewById(R.id.donebtn);
        doneBtn.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity2.this, MainActivity.class);

            // mengambil data
            String updatedName = getIntent().getStringExtra("name");
            String updatedUsername = getIntent().getStringExtra("username");
            String updatedImageUri = getIntent().getStringExtra("imageUri");

            // update data ke ma
            intent.putExtra("done", true);
            intent.putExtra("name", updatedName);
            intent.putExtra("username", updatedUsername);
            intent.putExtra("imageUri", updatedImageUri);

            startActivity(intent);
        });
    }
}
