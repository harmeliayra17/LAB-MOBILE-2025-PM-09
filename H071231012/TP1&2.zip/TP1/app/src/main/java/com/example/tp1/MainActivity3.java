package com.example.tp1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class MainActivity3 extends AppCompatActivity {

    TextInputEditText etName, etUsername, etEmail, etPassword;
    MaterialCardView btnSave;
    TextView btnGantiProfile;
    ImageView imgProfile;
    Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initialize views
        etName = findViewById(R.id.inputNama);
        etUsername = findViewById(R.id.inputNamaPengguna);
        etEmail = findViewById(R.id.inputEmail);
        etPassword = findViewById(R.id.inputKataSandi);
        btnSave = findViewById(R.id.back);
        btnGantiProfile = findViewById(R.id.gantiFoto);
        imgProfile = findViewById(R.id.imageView1);

        loadProfileData();

        //untuk klik buton ganti poto
        btnGantiProfile.setOnClickListener(v -> {
            // untuk pilih poto
            Intent openGalleryIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            openGalleryIntent.addCategory(Intent.CATEGORY_OPENABLE);
            openGalleryIntent.setType("image/*");
            openGalleryIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            openGallery.launch(Intent.createChooser(openGalleryIntent, "Pilih foto profil"));
        });

        // untuk sv data
        btnSave.setOnClickListener(v -> {
            String name = Objects.requireNonNull(etName.getText()).toString();
            String username = etUsername.getText().toString();
            String email = etEmail.getText().toString();
            String password = etPassword.getText().toString();

            // peringatan data harus terisi nd boleh kosong
            if (name.isEmpty() || username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity3.this, "Semua data harus terisi!", Toast.LENGTH_SHORT).show();
                return;
            }

            // kirim ke ma2 data terbaru yg sdh diedit di ma3
            Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
            intent.putExtra("name", name);
            intent.putExtra("username", username);
            intent.putExtra("email", email);
            intent.putExtra("password", password);

            if (imageUri != null) {
                intent.putExtra("imageUri", imageUri.toString());
            }

            startActivity(intent); // balik ke ma2
            Toast.makeText(this, "Profil disimpan", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void loadProfileData() {
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String username = intent.getStringExtra("username");
        String email = intent.getStringExtra("email");
        String password = intent.getStringExtra("password");
        String imageUriStr = intent.getStringExtra("imageUri");


        if (name != null) {
            etName.setText(name);
        }
        if (username != null) {
            etUsername.setText(username);
        }
        if (email != null) {
            etEmail.setText(email);
        }
        if (password != null) {
            etPassword.setText(password);
        }

        if (imageUriStr != null) {
            try {
                Uri imageUri = Uri.parse(imageUriStr);
                imgProfile.setImageURI(imageUri);
            } catch (Exception e) {
                e.printStackTrace();
                imgProfile.setImageResource(R.drawable.profile);
            }
        } else {
            imgProfile.setImageResource(R.drawable.profile);
        }
    }

    // buka galeri untuk ganti poto
    private final ActivityResultLauncher<Intent> openGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @SuppressLint("WrongConstant")
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            imageUri = data.getData();
                            imgProfile.setImageURI(imageUri);
                            int flag = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                            getContentResolver().takePersistableUriPermission(imageUri, flag);
                        }
                    }
                }
            }
    );
}
