package com.example.tp3.Data;

import com.example.tp3.Models.Post;
import com.example.tp3.Models.Upload;
import com.example.tp3.R;

import java.util.ArrayList;
import java.util.List;

public class DataPost {

    public static ArrayList<Post> posts = generateDummyPosts();
    public static List<Upload> uploadList = new ArrayList<>();

    private static ArrayList<Post> generateDummyPosts() {
        ArrayList<Post> posts = new ArrayList<>();

        List<Integer> nctd = new ArrayList<>();
        nctd.add(R.drawable.nctd1);
        nctd.add(R.drawable.nctd2);
        nctd.add(R.drawable.nctd3);
        nctd.add(R.drawable.nctd4);

        posts.add(new Post(R.drawable.nctd, nctd, "nct_dream", "321.000", "634", "",  "the dream show", "4.469", "13JT", "14", "NCT DREAM OFFICIAL", "NCT DREAM [DREAMSCAPE]", nctd, nctd));

        List<Integer> ilichil = new ArrayList<>();
        ilichil.add(R.drawable.ilichil1);
        ilichil.add(R.drawable.ilichil2);
        ilichil.add(R.drawable.ilichil3);
        ilichil.add(R.drawable.ilichil4);
        ilichil.add(R.drawable.ilichil5);


        posts.add(new Post(R.drawable.ilichil, ilichil, "nct127", "456.000", "674", "",  "the link", "5.034", "15,7JT", "15", "NCT 127 Official Instagram", "NCT 127 [WALK - The 6th Album]", ilichil, ilichil));

        List<Integer> wayv = new ArrayList<>();
        wayv.add(R.drawable.wayv1);
        wayv.add(R.drawable.wayv2);

        posts.add(new Post(R.drawable.wayv, wayv, "wayvofficial", "276.000", "563", "",  "wayv on the way", "2.861", "8,7JT", "14", "WayV", "WayV The 6th Mini Album [FREQUENCY]", wayv, wayv));

        List<Integer> nctw = new ArrayList<>();
        nctw.add(R.drawable.nctw1);
        nctw.add(R.drawable.nctw2);
        nctw.add(R.drawable.nctw3);

        posts.add(new Post(R.drawable.nctw, nctw, "nctwish_official", "182.000", "187", "",  "smcu palace", "2.504", "2,7JT", "7", "NCT WISH", "NCT WISH [poppop - The 2nd Mini Album]", nctw, nctw));

        return posts;
    }
}